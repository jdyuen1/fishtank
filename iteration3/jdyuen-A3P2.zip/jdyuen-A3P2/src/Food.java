import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.util.ArrayList;
import java.awt.Font;
import java.awt.FontMetrics;



public class Food extends SimulationObject {

	private Color foodColor;
	private Arc2D.Double foodShape1;
	private Arc2D.Double foodShape2;
		
	public Food(float x, float y, float size) {
		super(x, y, 1, 1, size);
		this.foodColor = Color.green;
	}
	
	
	@Override
	protected void setShapeAttributes() {
		this.foodShape1 = new Arc2D.Double(-10, -20, 30, 30, 90, 180, Arc2D.PIE);
		this.foodShape2 = new Arc2D.Double(-20, 5, 30, 30, -90, 180, Arc2D.PIE);
	}

	@Override
	public void draw(Graphics2D g) { 
		AffineTransform af = g.getTransform();
		g.translate(position.x, position.y);
		g.scale(size, size);
		g.setColor(foodColor);
		g.fill(foodShape1);
		g.fill(foodShape2);
		g.setTransform(af);

		g.setColor(Color.RED);
		if (toggle == true) {
			drawInfo(g);
		}
//		g.draw(getBoundary().getBounds2D());		


	}
	
	public void drawInfo(Graphics2D g) {
		AffineTransform at = g.getTransform();
		g.translate(position.x, position.y);
		Font f = new Font("Arial", Font.BOLD, 12); //ier 3
		g.setFont(f); //ier 3
		String st = String.format("%.2f", size); //iter 4
		FontMetrics metrics = g.getFontMetrics(f); //iter 5
		g.drawString(st, -metrics.stringWidth(st)/2, -height*size*25f); //iter 5
		g.setTransform(at);
	}
	
	public boolean checkFoodHit(MouseEvent e) {
		return getBoundary().contains(e.getX(), e.getY());
	}
	
	@Override
	public void setBoundingBox() {
		boundingBox = new Area(foodShape1);	
		boundingBox.add(new Area(foodShape2));

	}
	
	@Override
	public AffineTransform getAffineTransform() {
		AffineTransform at = new AffineTransform();		
		at.translate(position.x, position.y);
		at.scale(size, size);
		return at;
	}
	
	@Override
	public void update(ArrayList<SimulationObject> objList) {
		// nothing, food don't need to be updated
	}


	public boolean setToggle(boolean toggled) {
		return toggle = toggled;
	}
	
	public boolean getToggle() {
		return toggle;
	}


	public boolean setSelected(boolean select) {
		return selected = select;
	}
	
	public boolean getSelected() {
		return selected;
	}
}
