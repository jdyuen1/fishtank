import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.Timer;

public class AnimalPanel extends JPanel implements ActionListener {
	private ArrayList<SimulationObject> objList;
	private Timer timer;
	private Dimension panelSize;
	private int maxFood = 6;
	private int fishCount = 5;
	private int predCount = 2;
	private static String status = "Status";
	private boolean happen = false;
	private boolean globalToggle = false;
	private boolean shift, dkey;


	public AnimalPanel(Dimension initialSize) {
		super();
		this.panelSize = initialSize;		
		this.objList = new ArrayList<>();
		
		for(int i = 0; i < fishCount; i++) {
			objList.add(new Fish(Util.random(50, panelSize.width-50), Util.random(50, panelSize.height-50), Util.random(.05,.2)));		
		}
		
		for(int i = 0; i < predCount; i++) {
			objList.add(new Predator(Util.random(50, panelSize.width-50), Util.random(50, panelSize.height-50), Util.random(.1,.2)));
		}
		
		for(int i = 0; i < maxFood; i++) {
			objList.add(Util.randomFood(panelSize));
		}

		addMouseListener(new MyMouseAdapter());
		addKeyListener(new MyKeyAdapter());
		setFocusable(true);

		timer = new Timer(33, this);
		timer.start();

	}	
	
	private void drawStatusBar(Graphics2D g) {
		Font font = new Font("Arial", Font.BOLD, 12);
		g.setFont(font);
		FontMetrics metrics = g.getFontMetrics(font);
		
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(0, panelSize.height -metrics.getHeight()*2, panelSize.width, metrics.getHeight()*2);
		
		g.setColor(Color.BLACK);
		g.drawString(status, 24, panelSize.height - (int)(metrics.getHeight()*.75));
	}
	
	private class MyMouseAdapter extends MouseAdapter {
		public void mouseClicked(MouseEvent e){
			for(int i = 0; i < objList.size(); i++) {	
				if (objList.get(i) instanceof Food && ((Food) objList.get(i)).checkFoodHit(e) && (e.getModifiersEx() & InputEvent.CTRL_DOWN_MASK) >0) {
					objList.remove(objList.get(i));
					happen = true;
				}
				else if (objList.get(i) instanceof Fish && ((Fish) objList.get(i)).checkHit(e) && (e.getModifiersEx() & InputEvent.CTRL_DOWN_MASK) >0) {
					happen = true;
					if ((objList.get(i)).getSelected() == false) {
						(objList.get(i)).setSelected(true);
					}
					else if (( objList.get(i)).getSelected() == true) {
						( objList.get(i)).setSelected(false);
					}
				}
				else if (objList.get(i) instanceof Predator && ((Predator) objList.get(i)).checkHit(e) && (e.getModifiersEx() & InputEvent.CTRL_DOWN_MASK) >0) {
					happen = true;
					if (( objList.get(i)).getSelected() == false) {
						( objList.get(i)).setSelected(true);
					}
					else if (( objList.get(i)).getSelected() == true) {
						( objList.get(i)).setSelected(false);
					}
				}
			}
			if (happen == false) {
				objList.add(new Food(e.getX(), e.getY(), Util.random(.5, 1)));
			}
			happen = false;
		}
	}

	private class MyKeyAdapter extends KeyAdapter {
		public void keyPressed(KeyEvent e) {
			if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
				shift = true;
			}
			if (e.getKeyChar() == KeyEvent.VK_D) {
				dkey = true;
			}
			
			if (shift == true && dkey == true) {
				for (SimulationObject obj:objList ) {
					if (globalToggle == false) {
						obj.setToggle(true);
						globalToggle = true;
					}
					else if (globalToggle == true) {
						obj.setToggle(false);
						globalToggle = false;
					}
				}	
			}
		}
		
		public void keyReleased(KeyEvent e) {
			if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
				shift = false;
			}
			if (e.getKeyChar() == KeyEvent.VK_D) {
				dkey = false;
			}
		}
	}


	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		panelSize = getSize();
		setBackground(Color.BLUE);
		Graphics2D g2 = (Graphics2D) g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		//draw objects
		for (SimulationObject obj:objList ) obj.draw(g2);	
		drawStatusBar(g2);
	}	

	@Override
	public void actionPerformed(ActionEvent e) {
		for (int i = 0; i < objList.size(); i++) {
			objList.get(i).update(objList);	
		}
		if (Util.countFood(objList) < maxFood) {
			objList.add(Util.randomFood(panelSize));
		}
		if (Util.countFish(objList) < fishCount) {
			objList.add(new Fish(Util.random(50, panelSize.width-50), Util.random(50, panelSize.height-50), Util.random(.05,.2)));		
		}
		if (Util.countPred(objList) < predCount) {
			objList.add(new Predator(Util.random(50, panelSize.width-50), Util.random(50, panelSize.height-50), Util.random(.1,.2)));
		}
		
		for (SimulationObject obj:objList ) {
			if (globalToggle == false) {
				obj.setToggle(false);
			}
			else if (globalToggle == true) {
				obj.setToggle(true);
			}
		}

		repaint();
	}
	
	public static void setStatus(String st) {
		status = st;
	}
	
}
