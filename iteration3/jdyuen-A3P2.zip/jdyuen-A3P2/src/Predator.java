import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Random;
import processing.core.PVector;

public class Predator extends Animal{
	
	private Color color;
	private Ellipse2D.Double body;
	private Ellipse2D.Double eye;
	private Ellipse2D.Double eye2;
	private Ellipse2D.Double tail2;
	private Ellipse2D.Double fin;
	private Ellipse2D.Double fin2;	
	private Arc2D.Double curve;
	private Arc2D.Double curve2;
	private Arc2D.Double curve3;
	
	Random num = new Random();
	private int stripe = num.nextInt(2);
	
	public Predator(float x, float y, float size) {
		super(x, y, 200, 100, size);
		this.color = Color.GRAY.darker();
	}
	
	@Override
	protected void setShapeAttributes() {
		body = new Ellipse2D.Double(0, -height/2, width*2.25, height*1.5);
		fin = new Ellipse2D.Double(100, 0, width/3, height*2);
		fin2 = new Ellipse2D.Double(100, -150, width/3, height*2);
		eye = new Ellipse2D.Double(width/4, -height/10, width/10, width/10); 
		eye2 = new Ellipse2D.Double(width/4, height/3, width/10, width/10);
		curve = new Arc2D.Double(width/2 + 30, 25, width, width/10 - 20, 0, 180, Arc2D.OPEN);
		curve2 = new Arc2D.Double(width/2 + 30, 10, width, width/10 - 20, 0, 180, Arc2D.OPEN);
		curve3 = new Arc2D.Double(width/2 + 30, 40, width, width/10 - 20, 0, 180, Arc2D.OPEN);

		tail2 = new Ellipse2D.Double(300, -height/2+45, width, height/2);

	}
	
	protected void checkCollision(Dimension panelSize) {
		
		Rectangle2D.Double top = new Rectangle2D.Double(0, -10, panelSize.width, 10);
		Rectangle2D.Double bottom = new Rectangle2D.Double(0, panelSize.height, panelSize.width, 10);
		Rectangle2D.Double left = new Rectangle2D.Double(-10, 0, 10, panelSize.height);
		Rectangle2D.Double right = new Rectangle2D.Double(panelSize.width, 0, 10, panelSize.height);
		
		if (getBoundary().intersects(left) && speed.x < 0) speed.x *= -1;
		if (getBoundary().intersects(right) && speed.x > 0) speed.x *= -1;
		if (getBoundary().intersects(top) && speed.y < 0) speed.y *= -1;
		if (getBoundary().intersects(bottom) && speed.y > 0) speed.y *= -1;
	}
	
	@Override
	protected void traceBestFish(ArrayList<SimulationObject> animalList) {	
		if (animalList.size()>0) {	
			// find 1st target
			SimulationObject target = animalList.get(0);
			float distToTarget = PVector.dist(position, target.getPos());
			
			// find the closer one
			for (SimulationObject f:animalList) if (PVector.dist(position, f.getPos()) < distToTarget) {
				target = f;
				distToTarget = PVector.dist(position, target.getPos());
			}
			
			// make animal follow this target
			this.attractedBy(target);
		}	
	}

	@Override
	protected AffineTransform getAffineTransform() {
		AffineTransform at = new AffineTransform();		
		at.translate(position.x, position.y);
		at.rotate(speed.heading());
		at.scale(-size, -size);
		return at;
	}

	@Override
	protected boolean eatable(SimulationObject food) {
		return (food instanceof Food);
	}
	
	@Override
	public void draw(Graphics2D g) {
		AffineTransform af = g.getTransform();
		g.translate(position.x, position.y);					
		g.rotate(speed.heading());
		g.scale(-size, -size);

		g.setColor(color);
		if (isSick == true) {
			g.setColor(Color.GRAY.brighter());
		}
		g.fill(body);
		
		g.fill(fin);
		g.fill(fin2);
		
		g.fill(tail2);
						
		g.setColor(Color.BLACK);
		g.fill(eye);
		g.fill(eye2);

		if (stripe == 0) {
			g.draw(curve);
		}
		else {
			g.draw(curve2);
			g.draw(curve3);
		}
		g.setTransform(af);
		
		g.setColor(Color.BLACK);
		if (toggle == true) {
			drawInfo(g);
		}
		
		if (selected == true) {
			drawInfo(g);
		}
		
//		g.setColor(Color.red);
//		g.draw(getBoundary().getBounds2D());		
	}
	
	public void drawInfo(Graphics2D g) {
		AffineTransform at = g.getTransform();
		g.translate(position.x, position.y);
		float m = speed.mag();
		Font f = new Font("Arial", Font.BOLD, 12); //ier 3
		g.setFont(f); //ier 3
		String st = String.format("Energy: %.0f Speed: %.2f", energy, m); //iter 4
		FontMetrics metrics = g.getFontMetrics(f); //iter 5
		g.drawString(st, -metrics.stringWidth(st)/2, -height*size*5f); //iter 5
		g.setTransform(at);
	}

	@Override
	protected void setBoundingBox() {
		boundingBox = new Area(body);
		boundingBox.add(new Area(tail2));
		boundingBox.add(new Area(fin));
		boundingBox.add(new Area(fin2));
	}

	@Override
	protected boolean isfish(SimulationObject Fish) {
		return (Fish instanceof Fish);
	}

	@Override
	protected boolean ispred(SimulationObject Predator) {
		return (Predator instanceof Predator);
	}

	@Override
	protected void traceBestFood(ArrayList<SimulationObject> fList) {
		// TODO Auto-generated method stub
		
	}

}
