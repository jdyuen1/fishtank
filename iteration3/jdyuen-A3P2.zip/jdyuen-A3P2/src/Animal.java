import java.awt.event.MouseEvent;
import java.util.ArrayList;
import processing.core.PVector;


public abstract class Animal extends SimulationObject {
	protected PVector speed;					//position and speed
	protected float maxSpeed;				//speed limit
	protected float energy;					//energy
	protected float FULL_ENERGY = 1000;
	protected float maxSize;
	protected boolean isSick = false;

	public Animal(float x, float y, float w, float h, float size) {
		super(x, y, w, h, size);
		while (maxSpeed == 0) {
			this.maxSpeed = 9 - (size * 10);
		}
		this.maxSize = 0.3f;
		this.speed = Util.randomPVector(maxSpeed);
		energy = FULL_ENERGY;

	}

	protected void move() {
		speed.normalize().mult(maxSpeed);

		//decrease speed base on size
		float ratio = 1;
		if (size < .5f) ratio = 0.1f + 1.8f*size;
		else if (size < 1) ratio = 1f - 1.8f*(size-0.5f);
		else ratio = .1f;
		speed.mult(ratio);

		//lose energy
		energy-= FULL_ENERGY/(30*10); //30fps x 10sec living duration
		if (energy < 500) {
			isSick = true;
			speed.mult(0.5f);
		}

		//apply speed to position
		position.add(speed);
	}

	public void distractedBy(Animal a) {
		PVector path = PVector.sub(position, a.position);
		speed.add(path.normalize().mult(maxSpeed*5f)).limit(maxSpeed);
	}
	
	
	public boolean checkHit(MouseEvent e) {
		return getBoundary().contains(e.getX(), e.getY());
	}

	@Override
	public void update(ArrayList<SimulationObject> objList) {
		if (energy <= 0) {
			objList.remove(this);
			return;
		}
		ArrayList<SimulationObject> fList = getTargetList(objList);
		ArrayList<SimulationObject> fishList = getfishList(objList);
		ArrayList<SimulationObject> predList = getpredList(objList);

		for (SimulationObject f : fishList) {
			traceBestFood(fList);
			for (int i = 0; i < fList.size(); i++) {
				if (f.collides(fList.get(i))) {
					float foodSize = fList.get(i).getSize();
					if (energy < FULL_ENERGY) {
						energy += foodSize*100;
						//System.out.format("%s gains energy by %f units %n", animalType(), foodSize*100);
						AnimalPanel.setStatus(String.format("%s gains energy by %.2f units %n", animalType(), foodSize*100));
					} else {
						if (size < maxSize) {
							size += foodSize*0.01*size;
						}
						//System.out.format("%s grows by %.1f%%%n", animalType(), fList.get(i).getSize());
						AnimalPanel.setStatus(String.format("%s grows by %.1f%%%n", animalType(), fList.get(i).getSize()));
					}		
					objList.remove(fList.get(i));
				}
			}
			ArrayList<SimulationObject> fishyList = getfishList(objList);	
			for (int i = 0; i < fishyList.size(); i++) {
				if (collides(fishyList.get(i))) {
					if (getSize() < fishyList.get(i).getSize()) {
						this.distractedBy((Animal) fishyList.get(i));
					}
					else {
						((Animal) fishyList.get(i)).distractedBy(this);
					}
				}
			}
		}

		for (SimulationObject p : predList) {
			traceBestFish(fishList);
			for (int i = 0; i < fishList.size(); i++) {
				if (p.collides(fishList.get(i))) {
					float animalSize = fishList.get(i).getSize();
					if (energy < FULL_ENERGY) {
						energy += animalSize*100;
						//System.out.format("%s gains energy by %f units %n", animalType(), foodSize*100);
						AnimalPanel.setStatus(String.format("%s gains energy by %.2f units %n", animalType(), animalSize*100));
					} else {
						size += animalSize*0.01*size;
						//System.out.format("%s grows by %.1f%%%n", animalType(), fList.get(i).getSize());
						AnimalPanel.setStatus(String.format("%s grows by %.1f%%%n", animalType(), fList.get(i).getSize()));
					}		
					objList.remove(fishList.get(i));
				}
			}
			ArrayList<SimulationObject> predatorList = getpredList(objList);	
			for (int i = 0; i < predatorList.size(); i++) {
				if (collides(predatorList.get(i))) {
					if (getSize() < predatorList.get(i).getSize()) {
						this.distractedBy((Animal) predatorList.get(i));
					}
					else {
						((Animal) predatorList.get(i)).distractedBy(this);
					}
				}
			}
		}
		move();
	}		

	protected abstract void traceBestFood(ArrayList<SimulationObject> fList);
	protected abstract void traceBestFish(ArrayList<SimulationObject> animalList);
	protected abstract boolean eatable(SimulationObject food);
	protected abstract boolean isfish(SimulationObject Fish);
	protected abstract boolean ispred(SimulationObject Predator);

	protected ArrayList<SimulationObject> getTargetList(ArrayList<SimulationObject> fList) {
		ArrayList<SimulationObject> list = new ArrayList<>();
		for (SimulationObject f:fList) if (eatable(f)) list.add(f);
		return list;
	}

	protected ArrayList<SimulationObject> getfishList(ArrayList<SimulationObject> fishList) {
		ArrayList<SimulationObject> list = new ArrayList<>();
		for (SimulationObject f:fishList) if (isfish(f)) list.add(f);
		return list;
	}

	protected ArrayList<SimulationObject> getpredList(ArrayList<SimulationObject> predList) {
		ArrayList<SimulationObject> list = new ArrayList<>();
		for (SimulationObject f:predList) if (ispred(f)) list.add(f);
		return list;
	}

	private String animalType() {
		String type = "unknown animal";
		if (this instanceof Predator) type = "Predator";
		if (this instanceof Fish) type = "Fish";
		return type;
	}
	
	public boolean setToggle(boolean toggled) {
		return toggle = toggled;
	}
	
	public boolean getToggle() {
		return toggle;
	}
	
	public boolean setSelected(boolean select) {
		return selected = select;
	}
	
	public boolean getSelected() {
		return selected;
	}

	public boolean checkMouseHit(MouseEvent e) {
		return getBoundary().contains(e.getX(), e.getY());
	}

	protected void attractedBy(SimulationObject target) {
		float coef = .2f;	// coefficient of acceleration relative to maxSpeed
		PVector direction = PVector.sub(target.getPos(), position).normalize();
		PVector acceleration = PVector.mult(direction, maxSpeed*coef);
		speed.add(acceleration);
	}

}