import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.util.Random;
import processing.core.PVector;

public class Food {

	private static PVector foodPos;
	private static Color foodColor = Color.GREEN;
		
	public Food(int x, int y, Color c) {
	    foodPos = new PVector(x, y);
	    foodColor = c;
	}
	
	public void drawFood(Graphics2D g) { 
		g.setColor(foodColor);
		g.fillArc((int) foodPos.x, (int) foodPos.y, 30, 30, 90, 180);
		g.fillArc((int) foodPos.x-10, (int) foodPos.y+25, 30, 30, -90, 180);
	}
	
	public static Rectangle bounds() {
		return (new Rectangle((int) foodPos.x,(int) foodPos.y, 50, 70));
	}

	public static PVector getFoodPos() {
		return foodPos;
	}

	public static void setFoodPos(PVector foodPos) {
		Food.foodPos = foodPos;
	}

}
