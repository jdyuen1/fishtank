import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.util.Random;
import processing.core.PVector;


/*
 * Attempt at 2nd bonus task.  "Your animal will gracefully turn around towards the new food source, 
 * rather than abruptly changing the direction of the movement."
 */

public class Animal {
    private static PVector pos;
	private PVector speed, path, vel;
	private Color animalColor;
	private static int size;
	private double scale;
	private float angle, rotation = 0;
	private int left = 1;

	Random num = new Random();
	private int stripe = num.nextInt(2);
	private int tailSize = num.nextInt(2);

	public Animal(int x, int y, int size, int speedx, int speedy, Color c, double s1) {
		this.size = size;
	    this.pos = new PVector(x, y);
	    this.speed = new PVector(speedx, speedy);
	    this.scale = s1;
		animalColor = c;
	}
	
	public void movement() {
		PVector path = PVector.sub(Food.getFoodPos(), Animal.pos);
		path.normalize();
		angle = path.heading();
		vel = PVector.fromAngle(angle);
		vel.mult(2);
		Animal.pos.add(vel);
		
	}

	public static Rectangle bounds() {
		return (new Rectangle((int) pos.x, (int) pos.y, size,size));
	}
	
	public void drawAnimal(Graphics2D g) {
		AffineTransform af = g.getTransform();
		g.translate((int)pos.x, (int)pos.y);			
		if(angle <= rotation) { 						// Attempt at having gracefully turning for the animal. 
			rotation = (float) (rotation - 0.01);		// Incremental rotation instead of instantaneous
			g.rotate(rotation);							// Noticeable problem is the jittering due to the lack of precision in the 
		}												// addition/subtraction. The program adds/subtracts to 2 decimal places 
		else if (angle >= rotation) {					// but path.heading() can have from 6 to 8 decimal places.
			rotation = (float) (rotation + 0.01);
			g.rotate(rotation);
		}
		
		g.scale(-scale, -scale);
		
		g.setColor(animalColor);
						
		g.fillOval(-size/2, -size/2, size*3, size); 	// draw body
		
		g.fillOval(size/3, size/2 - size/2, size/2, size); // draw fins
		g.fillOval(size/3, -size - size/20, size/2, size); 
		
		g.setColor(Color.BLACK);
		g.fillOval(-size/6, -size/3, size/5, size/5); 	// draw eyes
		g.fillOval(-size/6, size/7, size/5, size/5);

		
		if (stripe == 0) {
			g.drawLine(size/2, -size/4, size + size/2, -size/4);
			g.drawLine(size/2, size/4, size + size/2, size/4);
			g.drawLine(size/2, size/4 - size/4, size + size/2, size/4 - size/4);
		}

		else {
			g.drawLine(size/2, -size/5, size + size/2, -size/5);
			g.drawLine(size/2, size/5, size + size/2, size/5);
		}
		
		g.setColor(animalColor);
		if (tailSize == 0) {		// draw tail
			g.fillOval(size + size, -size/5, size, size/3);
			g.fillOval(size + size, -size/3 - size/10, size, size/3);
			g.fillOval(size + size, size/20, size, size/3);
		}
		else {		
			g.fillOval(size + size, -size/5, size, size/3);
		}
		g.setTransform(af);

	}
}