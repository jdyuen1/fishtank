import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JPanel;
import javax.swing.Timer;

@SuppressWarnings("serial")
public class AnimalPanel extends JPanel implements ActionListener {
	private Animal animal;
	private Food food;
	private Dimension size;
	private Timer timer;
	private Random num = new Random();
	private int foodX = num.nextInt(700 + 1 - 50) + 50;
	private int foodY = num.nextInt(500 + 1 - 50) + 50;
	
	public AnimalPanel(Dimension initialSize) {
		super();
		size = initialSize;
		animal = new Animal(initialSize.width/3, initialSize.height/2, Math.min(initialSize.width,initialSize.height)/10, 
				0, 0, Color.orange, 1);
		
		food = new Food(foodX, foodY, Color.GREEN);
				
		this.setBackground(Color.cyan);
		
		timer = new Timer(33, null);
		timer.start();
		
		timer.addActionListener(this);
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		size = getSize();
		Graphics2D g2 = (Graphics2D) g;

		animal.drawAnimal(g2);
		food.drawFood(g2);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		animal.movement();	
		collision();
		repaint();	
	}
	
	public void collision() {

		Rectangle rectangle1 = Animal.bounds();
		Rectangle rectangle2 = Food.bounds();
		
		if (rectangle1.intersects(rectangle2)) {
			Random num = new Random();
			foodX = num.nextInt(700 + 1 - 50) + 50;
			foodY = num.nextInt(500 + 1 - 50) + 50;
			food = new Food(foodX, foodY, Color.GREEN);
			 	

		}
	}	
}
