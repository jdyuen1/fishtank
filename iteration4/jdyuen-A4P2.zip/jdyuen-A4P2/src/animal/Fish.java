package animal;


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Random;

import main.SimulationObject;
import other.Food;
import processing.core.PVector;

public class Fish extends Animal{
	
	private Color color;
	private Ellipse2D.Double body;
	private Ellipse2D.Double eye;
	private Ellipse2D.Double eye2;
	private Ellipse2D.Double tail1;
	private Ellipse2D.Double tail2;
	private Ellipse2D.Double fin;
	private Ellipse2D.Double fin2;	
	private Arc2D.Double curve;
	private Arc2D.Double curve2;
	private Arc2D.Double curve3;
	private boolean picked = false;

		
	Random num = new Random();
	private int stripe = num.nextInt(2);
	
	public Fish(float x, float y, float size) {
		super(x, y, 200, 100, size);
		this.color = Color.orange;
	}
	
	@Override
	protected void updateSpeed() {		
		//decrease speed base on size
		float ratio = 1;
		if (size < .5f) ratio = 0.1f + 1.8f*size;
		else if (size < 1) ratio = 1f - 1.8f*(size-0.5f);
		else ratio = .1f;
		
		if (isHungry == true) {
			MAX_SPEED = 4;
		}
		else if (freeze == true){
			MAX_SPEED = 0;
		}
		else {
			MAX_SPEED = 12;
		}
		
		if (energy < FULL_ENERGY*.3f) ratio *= (3f - 2f*(energy/(FULL_ENERGY*.3f)));
		
		speedMagnitude = ratio * MAX_SPEED;
	}
	
	@Override
	protected void setShapeAttributes() {
		body = new Ellipse2D.Double(0, -height/2, width*2.25, height*1.5);
		fin = new Ellipse2D.Double(100, 0, width/3, height*2);
		fin2 = new Ellipse2D.Double(100, -150, width/3, height*2);
		eye = new Ellipse2D.Double(width/4, -height/10, width/10, width/10); 
		eye2 = new Ellipse2D.Double(width/4, height/3, width/10, width/10);
		curve = new Arc2D.Double(width/2 + 30, 25, width, width/10 - 20, 0, 180, Arc2D.OPEN);
		curve2 = new Arc2D.Double(width/2 + 30, 10, width, width/10 - 20, 0, 180, Arc2D.OPEN);
		curve3 = new Arc2D.Double(width/2 + 30, 40, width, width/10 - 20, 0, 180, Arc2D.OPEN);

		tail1 = new Ellipse2D.Double(350, -150, width, height/2);
		tail2 = new Ellipse2D.Double(350, 150, width, height/2);  
	}
	
	@Override
	protected AffineTransform getAffineTransform() {
		AffineTransform at = new AffineTransform();		
		at.translate(position.x, position.y);
		at.rotate(speed.heading());
		at.scale(-size, -size);
		return at;
	}
	
	protected float setSpeed(float gspeed) {
		return MAX_SPEED = gspeed;
	}

	@Override
	protected boolean eatable(SimulationObject food) {
		return (food instanceof Food);
	}
	
	@Override
	public void draw(Graphics2D g) {
		AffineTransform af = g.getTransform();
		g.translate(position.x, position.y);					
		g.rotate(speed.heading());
		g.scale(-size, -size);
		
//		g.setColor(Color.red);
//		g.draw(fov);
		
		if (selected == true) {
			drawOutline(g);
		}
		g.setStroke(new BasicStroke(20));
		g.setColor(Color.BLACK);
		g.draw(body);
		g.draw(fin);
		g.draw(fin2);
		AffineTransform pt = g.getTransform();
		
		if (tail == false) {
			g.rotate(0.35);
			g.draw(tail1);	
			g.setTransform(pt);	
		}
		else {
			g.rotate(-0.35);
			g.draw(tail2);	
			g.setTransform(pt);	
		}
		
		
		g.setStroke(new BasicStroke(1));
		g.setColor(color);
		if (isHungry == true) {
			g.setColor(Color.GREEN.darker());
		}
		else {
			g.setColor(color);
		}
		g.fill(body);
		
		g.fill(fin);
		g.fill(fin2);
		
		AffineTransform at = g.getTransform();
		
		if (tail == false) {
			g.rotate(0.35);
			g.fill(tail1);	
			g.setTransform(at);	
		}
		else {
			g.rotate(-0.35);
			g.fill(tail2);	
			g.setTransform(at);	
		}	
		
		g.setColor(Color.BLACK);
		g.fill(eye);
		g.fill(eye2);

		g.setStroke(new BasicStroke(5));
		if (stripe == 0) {
			g.draw(curve);
		}
		else {
			g.draw(curve2);
			g.draw(curve3);
		}
		g.setStroke(new BasicStroke(1));
		
		g.setTransform(af);
		
		g.setColor(Color.ORANGE);
		if (toggle == true) {
			drawInfo(g);
		}
		
		if (selected == true) {
			drawInfo(g);
		}
		
//		g.setColor(Color.red);
//		g.draw(getBoundary().getBounds2D());		
	}
	
	protected void drawOutline(Graphics2D g) {
		g.setColor(Color.RED);
		g.setStroke(new BasicStroke(50));
		g.draw(body);		
		
		g.draw(fin);
		g.draw(fin2);
		
		
		AffineTransform at = g.getTransform();
		if (tail == false) {
			g.rotate(0.35);
			g.draw(tail1);	
			g.setTransform(at);	
		}
		else {
			g.rotate(-0.35);
			g.draw(tail2);	
			g.setTransform(at);	
		}
		
	}

	@Override
	protected void setBoundingBox() {
		boundingBox = new Area(body);
		boundingBox.add(new Area(fin));
		boundingBox.add(new Area(fin2));
		
		if (tail == false) {
			boundingBox.add(new Area(tail1));
		}
		else {
			boundingBox.add(new Area(tail2));
		}
	}
	
	public void setPicked(boolean value) {
		picked = value;
	}
	
	public boolean getPicked() {
		return picked;
	}
}
