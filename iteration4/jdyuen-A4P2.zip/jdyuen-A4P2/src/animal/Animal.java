package animal;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

import ddf.minim.AudioPlayer;
import ddf.minim.Minim;
import main.AnimalPanel;
import main.SimulationObject;
import other.Complex;
import other.Concave;
import other.Food;
import other.Marker;
import other.Marker2;
import other.Marker3;
import other.Marker4;

import java.awt.Image;
import java.awt.Polygon;
import java.awt.Shape;

import processing.core.PVector;
import util.MinimHelper;
import util.Util;


public abstract class Animal extends SimulationObject {
	protected PVector speed;					//position and speed
	protected float speedMagnitude;				//speed limit
	protected float energy;					//energy
	protected float FULL_ENERGY = 2000;
	protected float maxSize;
	protected float MAX_SPEED = 5;
	protected boolean isHungry = false;
	protected boolean freeze = false;
	protected int age;
	protected boolean weakfish = false;
	protected boolean tail = false;
	protected String status;
	private Minim minim;
	private AudioPlayer chew1;
	private AudioPlayer chew2;
	protected static boolean mutePred = false;
	protected static boolean muteFish = false;
	protected float dist;

	protected Arc2D.Double fov;				//visual

	public Animal(float x, float y, float w, float h, float size) {
		super(x, y, w, h, size);
		this.maxSize = 0.3f;
		speed = Util.randomPVector(speedMagnitude);
		energy = FULL_ENERGY;
		age = 0;

		Minim minim = new Minim (new MinimHelper());
		chew1 = minim.loadFile("chew1.mp3");
		chew2 = minim.loadFile("chew2.mp3");

		float sight = width*MAX_SPEED*.5f;
		fov = new Arc2D.Double(-sight, -sight, sight*2, sight*2, 15, 315, Arc2D.PIE);
	}

	public Shape getFOV() {
		AffineTransform at = new AffineTransform();		
		at.translate(position.x, position.y);
		at.rotate(speed.heading());
		at.scale(-size, -size);
		Area bBoxPlus = new Area(fov);
		return at.createTransformedShape(fov);
	}

	protected void updateSpeed() {		
		//decrease speed base on size
		float ratio = 1;
		if (size < .5f) ratio = 0.1f + 1.8f*size;
		else if (size < 1) ratio = 1f - 1.8f*(size-0.5f);
		else ratio = .1f;

		if (energy < FULL_ENERGY*.3f) ratio *= (3f - 2f*(energy/(FULL_ENERGY*.3f)));

		speedMagnitude = ratio * MAX_SPEED;
	}

	protected void move() {		
		//lose energy
		energy-= FULL_ENERGY*(size*10)/(30*60); //30fps x 60sec living duration

		//apply speed to position
		updateSpeed();
		speed.normalize().mult(speedMagnitude);
		position.add(speed);
	}

	protected void pushedAwayFrom(SimulationObject obstacle) {
		float coef = 5f;	// coefficient of acceleration relative to maxSpeed
		PVector direction = PVector.sub(position, obstacle.getPos()).normalize();
		PVector acceleration = PVector.mult(direction, speedMagnitude*coef);
		speed.add(acceleration);
	}

	protected void attractedBy(SimulationObject target) {
		float coef = .2f;	// coefficient of acceleration relative to maxSpeed
		PVector direction = PVector.sub(target.getPos(), position).normalize();
		PVector acceleration = PVector.mult(direction, speedMagnitude*coef);
		speed.add(acceleration);
	}
	
	protected void attractedSpot(SimulationObject target) {
		float coef = .4f;	// coefficient of acceleration relative to maxSpeed
		PVector direction = PVector.sub(target.getPos(), position).normalize();
		PVector acceleration = PVector.mult(direction, speedMagnitude*coef);
		speed.add(acceleration);
	}


	public boolean checkHit(MouseEvent e) {
		return getBoundary().contains(e.getX(), e.getY());
	}

	@Override
	public void update(ArrayList<SimulationObject> objList) {
		if (energy <= 0) {
			objList.remove(this);
			return;
		}
		age += 33;

		if (energy <= 1500) {
			isHungry = true;
		}
		else {
			isHungry = false;
		}

		if (age % 2 == 0) {
			if (tail == false) {
				tail = true;
			}
			else {
				tail = false;
			}
		}
		if ((energy <= 1750) || (this instanceof Predator)) {
			ArrayList<SimulationObject> wList = getTargetList(objList);
			for (int i = 0; i < wList.size(); i++) {
				if (wList.get(i) instanceof Fish) {
					weakfish = true;
				}
			}
			
			if ((this instanceof Predator) && (weakfish == false)) {
				ArrayList<SimulationObject> sList = getSpotList2(objList);
				traceBestSpot(sList);
				move();
				for (SimulationObject obj:objList) {
					if (((obj instanceof Marker2) || (obj instanceof Marker3)) && this.collides(obj)) {
						freeze = true;
					}
				}	
			}
			
			else {
				freeze = false;
				ArrayList<SimulationObject> fList = getTargetList(objList);
				traceBestFood(fList);
				move();
				
				for (int i = 0; i < fList.size(); i++) 
					if (((this instanceof Predator) && (((Animal) fList.get(i)).push(this) == false)) || this instanceof Fish) {
						if (collides(fList.get(i))) {
							float foodSize = fList.get(i).getSize();
							if (fList.get(i) instanceof Fish) {
								energy += foodSize*1500;
							}
							else {
								energy += foodSize*10;						
							}
							AnimalPanel.setStatus(String.format("%s gains %.2f units of energy => %.2f%n", animalType(), foodSize*100, energy));
		
							if (muteFish == false) {
								if (fList.get(i) instanceof Fish) {
									chew2.rewind();
									chew2.play();
								}
							}
		
							if (mutePred == false) {
								if (fList.get(i) instanceof Food) {
									chew1.rewind();
									chew1.play();
								}
							}			
		
							objList.remove(fList.get(i));
						}
					}
				ArrayList<SimulationObject> temp = new ArrayList<SimulationObject>();
				for (SimulationObject obj:objList) {
					for (int i = 0; i < fList.size(); i++) {
						if ((obj instanceof Complex) && (fList.get(i) instanceof Food) && obj.collides(fList.get(i))) {
							temp.add(fList.get(i));
						}
						if ((obj instanceof Concave) && (fList.get(i) instanceof Food) && obj.collides(fList.get(i))) {
							temp.add(fList.get(i));
						}			
					}
				}
	
				for (int i = 0; i < temp.size(); i++) {
					objList.remove(temp.get(i));
				}
				
				for (SimulationObject obj:objList) {
					if (this instanceof Fish) {
						if ( ((obj instanceof Predator) && this.push(obj))) {
							ArrayList<SimulationObject> rList = getSpotList(objList);
							run(rList);
							move();
						}
					}
				}				
			}
		}
		else if (this instanceof Fish) {
			ArrayList<SimulationObject> sList = getSpotList(objList);
			traceBestSpot(sList);
			move();
			for (SimulationObject obj:objList) {
				if (((obj instanceof Marker) || (obj instanceof Marker4)) && this.collides(obj)) {
					freeze = true;
				}
				else if ( ((obj instanceof Predator) && this.push(obj))) {
					ArrayList<SimulationObject> rList = getSpotList(objList);
					run(rList);
					move();
				}
			}
		}
		
		//non-eat-able object
		for (SimulationObject obj:objList) {
			if ( ((obj instanceof Fish) && obj.getSize() > this.getSize() && this.collides(obj))) {
				this.pushedAwayFrom(obj);
			}

			if ( ((obj instanceof Predator) && obj.getSize() > this.getSize() && this.collides(obj))) {
				this.pushedAwayFrom(obj);
			}

			if (((obj instanceof Complex) && this.push(obj))) {
				this.pushedObstacle(obj);
			}

			if (((obj instanceof Concave) && this.push(obj))) {
				this.pushedObstacle(obj);
			}
		}
		weakfish = false;
	}	

	protected boolean push(SimulationObject other) {
		return (getFOV().intersects(other.getBoundary().getBounds2D()));
	}
	
//	protected boolean detect(SimulationObject other) {
//		return (getFOV().intersects(((Animal) other).getFOV().getBounds2D()));
//	}

	protected void pushedObstacle(SimulationObject obstacle) {
		float coef = 0.4f;	// coefficient of acceleration relative to maxSpeed
		PVector direction = PVector.sub(position, obstacle.getPos()).normalize();
		PVector acceleration = PVector.mult(direction, speedMagnitude*coef);
		speed.add(acceleration);
	}

	protected abstract boolean eatable(SimulationObject food);

	protected ArrayList<SimulationObject> getTargetList(ArrayList<SimulationObject> fList) {
		ArrayList<SimulationObject> list = new ArrayList<>();
		for (SimulationObject f:fList) if (eatable(f)) list.add(f);
		return list;
	}
	
	protected ArrayList<SimulationObject> getSpotList(ArrayList<SimulationObject> sList) {
		ArrayList<SimulationObject> list = new ArrayList<>();
		for (SimulationObject f:sList) {
			if ((f instanceof Marker) || (f instanceof Marker4)) {
				list.add(f);
			}
		}
		return list;
	}
	
	protected ArrayList<SimulationObject> getSpotList2(ArrayList<SimulationObject> sList) {
		ArrayList<SimulationObject> list = new ArrayList<>();
		for (SimulationObject f:sList) {
			if ((f instanceof Marker2) || (f instanceof Marker3)) {
				list.add(f);
			}
		}
		return list;
	}

	protected void traceBestFood(ArrayList<SimulationObject> fList) {	
		if (fList.size()>0) {	
			// set the 1st item as default target
			SimulationObject target = fList.get(0);
			float targetAttraction = this.getAttraction(target);

			// find the closer one
			for (SimulationObject f:fList) if (this.getAttraction(f) > targetAttraction) {
				target = f;
				targetAttraction = this.getAttraction(target);
			}
			
			dist = targetAttraction;

			// make animal follow this target
			this.attractedBy(target);
		}	
	}
	
	protected void traceBestSpot(ArrayList<SimulationObject> sList) {	
		if (sList.size()>0) {	
			// set the 1st item as default target
			SimulationObject target = sList.get(0);
			float targetAttraction = this.getAttraction(target);

			// find the closer one
			for (SimulationObject f:sList) if (this.getAttraction(f) > targetAttraction) {
				target = f;
				targetAttraction = this.getAttraction(target);
			}

			// make animal follow this target
			this.attractedSpot(target);
		}	
	}
	
	protected void run(ArrayList<SimulationObject> sList) {	
		if (sList.size()>0) {	
			// set the 1st item as default target
			SimulationObject target = sList.get(0);
			float targetAttraction = this.getAttraction(target);

			// find the closer one
			for (SimulationObject f:sList) if (this.getAttraction(f) < targetAttraction) {
				target = f;
				targetAttraction = this.getAttraction(target);
			}

			// make animal follow this target
			this.attractedSpot(target);
		}	
	}

	protected void drawInfo(Graphics2D g) {
		AffineTransform at = g.getTransform();
		g.translate(position.x, position.y);
		if (isHungry == true) {
			status = "Hungry";
		}
		else {
			status = "Satiated";
		}

		String st2 = "Status : " + String.format("%s", status);
		String st3 = "Energy : " + String.format("%.2f", energy);

		Font f = new Font("Courier", Font.PLAIN, 12);
		FontMetrics metrics = g.getFontMetrics(f);

		float textWidth = metrics.stringWidth(st3);
		float textHeight = metrics.getHeight();
		float margin = 12, spacing = 1;

		g.setColor(new Color(255,255,255,175));
		if (age < 1200 && (age % 250) < 100) g.setColor(new Color(255,255,255,0));
		g.fillRect((int)(-textWidth/2-margin), 
				(int)(-height*size - textHeight*3f - spacing - margin), 
				(int)(textWidth + margin*2f), 
				(int)(textHeight*3f + spacing + margin));

		g.setColor(Color.blue.darker());
		g.drawString(this.animalType(), -metrics.stringWidth(this.animalType())/2,  -height*size*.75f - margin - (textHeight + spacing)*2f);

		if (energy <= 1000) {
			g.setColor(Color.red.darker());
		}
		else if (energy <= 1750) {
			g.setColor(Color.orange);
		}
		else {
			g.setColor(Color.green.darker());
		}
		g.drawString(st2, -textWidth/2, -height*size*.75f - margin - (textHeight + spacing)*1f);
		g.setColor(Color.black);
		if (energy < FULL_ENERGY*.3f) {
			g.setColor(Color.red);
		}
		g.drawString(st3, -textWidth/2, -height*size*.75f - margin);

		g.setTransform(at);
	}

	private String animalType() {
		String type = "unknown animal";
		if (this instanceof Predator) type = "Predator";
		if (this instanceof Fish) type = "Fish";
		return type;
	}

	public boolean setToggle(boolean toggled) {
		return toggle = toggled;
	}

	public boolean getToggle() {
		return toggle;
	}

	public boolean setSelected(boolean select) {
		return selected = select;
	}

	public boolean getSelected() {
		return selected;
	}

	public boolean checkMouseHit(MouseEvent e) {
		return getBoundary().contains(e.getX(), e.getY());
	}

	protected float getAttraction(SimulationObject target) {
		return target.getSize()*10/PVector.dist(position, target.getPos());
	}

	public static void setPredSound(boolean value) {
		mutePred = value;
	}

	public static void setFishSound(boolean value) {
		muteFish = value;
	}
	
	public boolean getHungry() {
		return isHungry;
	}
	
	public float getEnergy() {
		return energy;
	}
	
	public float getDist() {
		return dist;
	}

}