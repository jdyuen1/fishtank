package animal;


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

import main.SimulationObject;
import processing.core.PVector;

public class Predator extends Animal{
	
	private Color color;
	private Ellipse2D.Double body;
	private Ellipse2D.Double eye;
	private Ellipse2D.Double eye2;
	private Ellipse2D.Double tail1;
	private Ellipse2D.Double tail2;
	private Arc2D.Double fin11;
	private Arc2D.Double fin22;
	private Arc2D.Double curve;
	public static Comparator<SimulationObject> FishComparator;
	private int count = 0;
			
	public Predator(float x, float y, float size) {
		super(x, y, 200, 100, size);
		this.color = Color.GRAY.darker();
	}
	
	@Override
	protected void setShapeAttributes() {
		body = new Ellipse2D.Double(0, -height/2, width*2.5, height*1.5);
		fin11 = new Arc2D.Double(width/4, 150, width, height, 0, 120, Arc2D.PIE);
		fin22 = new Arc2D.Double(width/2 - 10, -220, width, height, 0, -120, Arc2D.PIE);
		eye = new Ellipse2D.Double(width/4, -height/2.1, width/5, width/5); 
		eye2 = new Ellipse2D.Double(width/4, height/1.6, width/5, width/5);
		curve = new Arc2D.Double(width*1.2, 15, width/1.2, height/5, 90,  180, Arc2D.OPEN);

		tail2 = new Ellipse2D.Double(420, 150, width, height/2);
		tail1 = new Ellipse2D.Double(420, -150, width, height/2);

	}
	
	@Override
	protected void updateSpeed() {		
		//decrease speed base on size
		float ratio = 1;
		if (size < .5f) ratio = 0.1f + 1.8f*size;
		else if (size < 1) ratio = 1f - 1.8f*(size-0.5f);
		else ratio = .1f;
		
		if (freeze == true){
			MAX_SPEED = 0;
		}
		else {
			MAX_SPEED = 5;
		}
		
		if (energy < FULL_ENERGY*.3f) ratio *= (3f - 2f*(energy/(FULL_ENERGY*.3f)));
		
		speedMagnitude = ratio * MAX_SPEED;
	}
	
	@Override
	protected AffineTransform getAffineTransform() {
		AffineTransform at = new AffineTransform();		
		at.translate(position.x, position.y);
		at.rotate(speed.heading());
		at.scale(-size, -size);
		return at;
	}

	@Override
	protected boolean eatable(SimulationObject food) {
		return (food instanceof Animal && !(food instanceof Predator) && (((Animal) food).getHungry() == true));
	}
	
	@Override
	public void draw(Graphics2D g) {
		AffineTransform af = g.getTransform();
		g.translate(position.x, position.y);					
		g.rotate(speed.heading());
		g.scale(-size, -size);
		
//		g.setColor(Color.red);
//		g.draw(fov);
	
		if (selected == true) {
			drawOutline(g);
		}
		g.setStroke(new BasicStroke(15));
		g.setColor(Color.BLACK);
		AffineTransform ot = g.getTransform();
		g.rotate(-1.134);
		g.draw(fin11);
		g.setTransform(ot);
		
		AffineTransform pt = g.getTransform();
		g.rotate(1.134);
		g.draw(fin22);
		g.setTransform(pt);
		
		g.draw(body);
		
		AffineTransform lt = g.getTransform();
		if (tail == false) {
			g.rotate(0.35);
			g.draw(tail1);	
			g.setTransform(lt);	
		}
		else {
			g.rotate(-0.35);
			g.draw(tail2);	
			g.setTransform(lt);	
		}	
		
		
		g.setStroke(new BasicStroke(1));
		g.setColor(Color.BLACK);
		g.fill(eye);
		g.fill(eye2);
		
		g.setColor(color);
		g.fill(body);
		
		AffineTransform at = g.getTransform();
		g.rotate(-1.134);
		g.fill(fin11);
		g.setTransform(at);
		
		AffineTransform bt = g.getTransform();
		g.rotate(1.134);
		g.fill(fin22);
		g.setTransform(bt);
		
		
		AffineTransform zt = g.getTransform();
		if (tail == false) {
			g.rotate(0.35);
			g.fill(tail1);	
			g.setTransform(zt);	
		}
		else {
			g.rotate(-0.35);
			g.fill(tail2);	
			g.setTransform(zt);	
		}	
						
		g.setStroke(new BasicStroke(5));
		g.setColor(Color.BLACK);
		g.draw(curve);
		g.setStroke(new BasicStroke(1));

		g.setTransform(af);
		
		g.setColor(Color.BLACK);
		if (toggle == true) {
			drawInfo(g);
		}
		
		if (selected == true) {
			drawInfo(g);
		}
		
		g.setStroke(new BasicStroke(1));
		
//		g.setColor(Color.red);
//		g.draw(getBoundary().getBounds2D());		
	}
	
	protected void drawOutline(Graphics2D g) {
		g.setColor(Color.RED);
		g.setStroke(new BasicStroke(50));
		g.draw(body);		
		AffineTransform at = g.getTransform();
		g.rotate(-1.134);
		g.draw(fin11);
		g.setTransform(at);
		AffineTransform bt = g.getTransform();
		g.rotate(1.134);
		g.draw(fin22);
		g.setTransform(bt);
		
		if (tail == false) {
			g.rotate(0.35);
			g.draw(tail1);	
			g.setTransform(at);	
		}
		else {
			g.rotate(-0.35);
			g.draw(tail2);	
			g.setTransform(at);	
		}	
	}

	@Override
	protected void setBoundingBox() {
		boundingBox = new Area(body);
		boundingBox.add(new Area(fin11));
		
		if (tail == false) {
			boundingBox.add(new Area(tail1));
	
		}
		else {
			boundingBox.add(new Area(tail2));
		}	
	}

	@Override
	protected void traceBestFood(ArrayList<SimulationObject> fList) {	
		if (fList.size()>0) {
			if (FishComparator == null) { 
				super.traceBestFood(fList);
			} else {
				Collections.sort(fList, FishComparator);
				((Fish) fList.get(0)).setPicked(true);
				
				if (fList.size() > 1) {
					((Fish) fList.get(1)).setPicked(true);					
				}
				if (fList.size() > 2) {
					((Fish) fList.get(2)).setPicked(true);					
				}
				this.attractedBy(fList.get(0));
			}
		}	
	}
}
