package other;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import main.SimulationObject;

public class Concave extends SimulationObject {
	
	private GeneralPath concavePath;
	private int xPoints[] = { 0, 30, 24, 18, 17, 16, 15, 16, 17, 18, 24, 30, 0 };
	private int yPoints[] = { 100, 100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 0, 0 };

	private Rectangle2D.Double hitConcave;
	
	public Concave(float x, float y, float w, float h, float size) {
		super(x, y, w, h, size);
		concavePath = new GeneralPath();
		
		concavePath.moveTo(xPoints[0], yPoints[0]);
		
		for (int index = 1; index < xPoints.length; index++) {
			concavePath.lineTo(xPoints[index], yPoints[index]);
		}
		
		concavePath.closePath();
	}


	@Override
	public void draw(Graphics2D g2) {
		AffineTransform at = g2.getTransform();
		g2.translate(position.x, position.y);
		drawConcave(g2);
		g2.setTransform(at);
	}
	
	public void drawConcave(Graphics2D g2) {

		AffineTransform af = g2.getTransform();
		g2.setColor(Color.MAGENTA.darker());
		g2.fill(concavePath);
		g2.setTransform(af);

	}


	@Override
	public void update(ArrayList<SimulationObject> objList) {
		// TODO Auto-generated method stub
		
	}


	@Override
	protected void setShapeAttributes() {
		hitConcave = new Rectangle2D.Double(0, 0, 30, 100);
		
	}

	@Override
	protected void setBoundingBox() {
		boundingBox = new Area(hitConcave);		
	}


	@Override
	protected AffineTransform getAffineTransform() {
		AffineTransform at = new AffineTransform();		
		at.translate(position.x, position.y);
		return at;	
	}

	public boolean setToggle(boolean toggled) {
		return toggle = toggled;
	}
	
	public boolean getToggle() {
		return toggle;
	}


	public boolean setSelected(boolean select) {
		return selected = select;
	}
	
	public boolean getSelected() {
		return selected;
	}

}
