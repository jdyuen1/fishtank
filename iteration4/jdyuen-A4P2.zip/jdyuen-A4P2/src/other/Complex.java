package other;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.*;
import java.util.ArrayList;

import main.SimulationObject;

public class Complex extends SimulationObject {

	private Ellipse2D.Double shape;
	private Rectangle2D.Double hit;
	private float len = 1024;

	public Complex(float x, float y, float w, float h, float size) {
		super(x, y, 1, 1, size);
	}

	@Override
	public void draw(Graphics2D g2) {
		AffineTransform at = g2.getTransform();
		g2.translate(position.x, position.y);
		drawComplex(g2, len);
		
		g2.setTransform(at);
	}		
	
	public void drawComplex(Graphics2D g2, float len) {
		shape = new Ellipse2D.Double(0, 0, 25, 75);

		g2.setStroke(new BasicStroke(3));
		g2.setColor(Color.RED);

		AffineTransform af = g2.getTransform();

		g2.draw(shape);
		g2.rotate(Math.toRadians(45), 25, 25);
		
		len *= .5; 
		if (len > 2) {
			drawComplex(g2, len);
		}
		g2.setTransform(af);
	}

	@Override
	protected void setShapeAttributes() {
		hit = new Rectangle2D.Double(-25, -25, 100, 100);
	}
	
	@Override
	protected AffineTransform getAffineTransform() {
		AffineTransform at = new AffineTransform();		
		at.translate(position.x, position.y);
		return at;	
	}
	
	@Override
	protected void setBoundingBox() {
		boundingBox = new Area(hit);
	}

	@Override
	public void update(ArrayList<SimulationObject> objList) {
		// nothing, food don't need to be updated
	}


	public boolean setToggle(boolean toggled) {
		return toggle = toggled;
	}
	
	public boolean getToggle() {
		return toggle;
	}


	public boolean setSelected(boolean select) {
		return selected = select;
	}
	
	public boolean getSelected() {
		return selected;
	}

}
