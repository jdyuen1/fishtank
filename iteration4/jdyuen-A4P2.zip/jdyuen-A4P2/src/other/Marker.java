package other;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.util.ArrayList;

import main.SimulationObject;

public class Marker extends SimulationObject{
	
	private Arc2D.Double shape;

	public Marker(float x, float y, float w, float h, float size) {
		super(x, y, w, h, size);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void draw(Graphics2D g2) {
		AffineTransform af = g2.getTransform();
		g2.translate(position.x, position.y);
		g2.scale(size, size);	
		g2.setColor(new Color(0.0f, 1.0f, 0.0f, 0.0f));
		g2.fill(shape);
		g2.setTransform(af);
	}

	@Override
	public void update(ArrayList<SimulationObject> objList) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void setShapeAttributes() {
		this.shape = new Arc2D.Double(0, 0, 30, 30, 0, 360, Arc2D.PIE);		
	}

	@Override
	protected void setBoundingBox() {
		boundingBox = new Area(shape);			
	}

	@Override
	public AffineTransform getAffineTransform() {
		AffineTransform at = new AffineTransform();		
		at.translate(position.x, position.y);
		at.scale(size, size);
		return at;
	}

	public boolean setToggle(boolean toggled) {
		return toggle = toggled;
	}
	
	public boolean getToggle() {
		return toggle;
	}


	public boolean setSelected(boolean select) {
		return selected = select;
	}
	
	public boolean getSelected() {
		return selected;
	}

}
