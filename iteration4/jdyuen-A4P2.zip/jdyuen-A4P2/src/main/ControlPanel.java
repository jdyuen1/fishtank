package main;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Comparator;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import animal.Animal;
import animal.Fish;
import animal.Predator;

public class ControlPanel extends JPanel {
	
	private Container center;
	private JLabel fNum, fdMax, size;
	private JTextField fNumField, sizeField;
	
	private Container top;
	private JButton addFish, b1, b2, sortButton;
	
	private Container bottom;
	private JLabel statusLabel;
	protected static int foodValue = 5;
	private float sizeValue = 0;
	private float changedValue;
	
	private ButtonGroup radioGroup;
	private JRadioButton sortByEnergy;
	private JRadioButton sortByEnergySize;
	private JRadioButton sortByEnergyDistSize;
	
	public ControlPanel() {
		setComponentsAttributes();
		this.setLayout(new BorderLayout());
		this.add(center, BorderLayout.CENTER);
		this.add(bottom, BorderLayout.SOUTH);
		this.add(top, BorderLayout.NORTH);
	}
	
	private void setComponentsAttributes() {	
		
		// top
		fNum = new JLabel("Total Alive Fish: ");
		fdMax = new JLabel("Max Food: ");
		size = new JLabel("Change Size: ");
		
		sortButton = new JButton("Sort");
		
		JCheckBox checkBox1 = new JCheckBox("Mute Background Sound");
		JCheckBox checkBox2 = new JCheckBox("Mute Predator Sound");
		JCheckBox checkBox3 = new JCheckBox("Mute Fish Sound");
		
		fNumField = new JTextField(5);
		fNumField.setHorizontalAlignment(SwingConstants.CENTER);
		fNumField.setFocusable(false);
		
		SpinnerModel value = new SpinnerNumberModel(5, 1, 15, 1);
		JSpinner fdMaxField = new JSpinner(value);
		fdMaxField.addChangeListener(new SpinnerListener());
		fdMaxField.setFocusable(false);
		
		sizeField = new JTextField(5);
		sizeField.setHorizontalAlignment(SwingConstants.CENTER);
		sizeField.setFocusable(false);
		b1=new JButton("+");  
	    b2=new JButton("-");  

		center = new Container();
		center.setLayout(new FlowLayout(FlowLayout.LEADING, 10,  5));
		center.add(Box.createHorizontalStrut(2));
		center.add(fNum);
		center.add(fNumField);
		center.add(fdMax);
		center.add(fdMaxField);
		center.add(size);
		center.add(b1);
		center.add(sizeField);
		center.add(b2);
				
		center.add(Box.createRigidArea(new Dimension(50,0)));
		
		radioGroup = new ButtonGroup();
		
		sortByEnergy = new JRadioButton("Energy");
		center.add(sortByEnergy);
		radioGroup.add(sortByEnergy);
		
		sortByEnergySize = new JRadioButton("Energy and Size");
		center.add(sortByEnergySize);
		radioGroup.add(sortByEnergySize);
		
		sortByEnergyDistSize = new JRadioButton("Energy Distance and Size");
		center.add(sortByEnergyDistSize);
		radioGroup.add(sortByEnergyDistSize);
		
		//center
		addFish = new JButton("Add Fish");
		addFish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				AnimalPanel.addFish();		
			}
		});		
		
		b1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==b1) {
					if(sizeValue > 0.00) {
						changedValue = (float) (sizeValue + 0.03);
						AnimalPanel.setSelectedSize(changedValue);
					}
				}
			}
		});
		
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==b2) {
					if(sizeValue > 0.00) {
						changedValue = (float) (sizeValue - 0.03);
						AnimalPanel.setSelectedSize(changedValue);
					}
				}
			}
		});
				
		top = new Container();
		top.setLayout(new FlowLayout(FlowLayout.LEADING));
		top.add(addFish);
		top.add(checkBox1);
		checkBox1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(checkBox1.isSelected()) {
					AnimalPanel.setBackgroundSound(true);
				}
				else {
					AnimalPanel.setBackgroundSound(false);
				}
			}
		});		

		top.add(checkBox2);
		checkBox2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(checkBox2.isSelected()) {
					Animal.setPredSound(true);
				}
				else {
					Animal.setPredSound(false);
				}
					
			}
		});	
		top.add(checkBox3);
		checkBox3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(checkBox3.isSelected()) {
					Animal.setFishSound(true);
				}
				else {
					Animal.setFishSound(false);
				}
			}
		});	
		top.add(Box.createRigidArea(new Dimension(250,0)));
		top.add(sortButton);
		sortButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				
				if (sortByEnergy.isSelected()) {
					Predator.FishComparator = new Comparator<SimulationObject>() {
						@Override
						public int compare(SimulationObject f1, SimulationObject f2) {
							if (((Animal) f1).getEnergy() < ((Animal) f2).getEnergy()) {
								return -1;
							}
							if (((Animal) f1).getEnergy() > ((Animal) f2).getEnergy()) {
								return 1;
							}
							return 0;
						}
					};
				}	
				
				if (sortByEnergySize.isSelected()) {
					Predator.FishComparator = new Comparator<SimulationObject>() {
						@Override
						public int compare(SimulationObject f1, SimulationObject f2) {
							if (((Animal) f1).getEnergy() < ((Animal) f2).getEnergy()) {
								return -1;
							}
							if (((Animal) f1).getEnergy() > ((Animal) f2).getEnergy()) {
								return 1;
							}
							
							if (((Animal) f1).getSize() < ((Animal) f2).getSize()) {
								return -1;
							}
							if (((Animal) f1).getSize() > ((Animal) f2).getSize()) {
								return 1;
							}							
							
							return 0;
						}
					};
				}
				
				if (sortByEnergyDistSize.isSelected()) {
					Predator.FishComparator = new Comparator<SimulationObject>() {
						@Override
						public int compare(SimulationObject f1, SimulationObject f2) {
							if (((Animal) f1).getEnergy() < ((Animal) f2).getEnergy()) {
								return -1;
							}
							if (((Animal) f1).getEnergy() > ((Animal) f2).getEnergy()) {
								return 1;
							}
							
							if (((Animal) f1).getSize() < ((Animal) f2).getSize()) {
								return -1;
							}
							if (((Animal) f1).getSize() > ((Animal) f2).getSize()) {
								return 1;
							}	
							
							if (((Animal) f1).getDist() < ((Animal) f2).getDist()) {
								return -1;
							}
							if (((Animal) f1).getDist() > ((Animal) f2).getDist()) {
								return 1;
							}		
									
							return 0;
						}
					};
				}
			
			}	
		});		
		
		statusLabel = new JLabel("Status");
		bottom = new Container();
		bottom.setLayout(new FlowLayout(FlowLayout.LEADING, 12, 5));
		bottom.add(statusLabel);
		bottom.setBackground(Color.DARK_GRAY);
	}
	
	class SpinnerListener implements ChangeListener {
		public void stateChanged(ChangeEvent evt) {
			JSpinner fdMaxField = (JSpinner) evt.getSource();
			foodValue = (int) fdMaxField.getValue();
		}		
	}
	
	public void update(AnimalPanel p) {
		statusLabel.setText(p.getStatus());
		fNumField.setText(String.format("%d", p.countObject(Fish.class)));
		sizeField.setText(String.format("%.2f", selectedSize(p)));
	}
	
	public Float selectedSize(AnimalPanel p) {
		sizeValue = p.getSelectedSize();
		changedValue = sizeValue;
		
		if (sizeValue != changedValue) {
			sizeValue = changedValue;
		}
				
		if(sizeValue > 0.0) {
			return sizeValue;
		}
		return (float) 0.00;
	}	

	public static int getSpinner() {
		return foodValue;
	}

}
