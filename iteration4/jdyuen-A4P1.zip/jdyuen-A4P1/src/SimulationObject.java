import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.util.ArrayList;

import processing.core.PVector;

public abstract class SimulationObject {
	protected PVector position;
	protected float width, height;
	protected float size;
	protected Area boundingBox;
	protected boolean toggle = false;
	protected boolean selected = false;
	protected float selectedsize;

	
	public SimulationObject(float x, float y, float w, float h, float size) {
		this.position = new PVector(x,y);
		this.width = w;
		this.height = h;
		this.size = size;
		setShapeAttributes();
		setBoundingBox();
	}
	
	public abstract void draw(Graphics2D g2);
	public abstract void update(ArrayList<SimulationObject> objList);
	protected abstract void setShapeAttributes();
	protected abstract void setBoundingBox();
	protected abstract AffineTransform getAffineTransform();
	public abstract boolean setToggle(boolean b);
	public abstract boolean setSelected(boolean b);
	public abstract boolean getSelected();
	public abstract boolean getToggle();
	
	public float getSize() {
		return size;
	}
	
	public float setSize(float gsize) {
		return size = gsize;
	}
	
	public PVector getPos() {
		return position;
	}
	
	public Shape getBoundary() {
		return getAffineTransform().createTransformedShape(boundingBox);
	}
	
	protected boolean collides(SimulationObject other) {
		return (getBoundary().intersects(other.getBoundary().getBounds2D()) &&
				other.getBoundary().intersects(getBoundary().getBounds2D()) );
	}
}
