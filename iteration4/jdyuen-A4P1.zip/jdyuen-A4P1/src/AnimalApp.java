import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JFrame;

public class AnimalApp extends JFrame {
	
	public AnimalApp(String title) {
		super(title);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		ControlPanel aPanel = new ControlPanel();
		AnimalPanel mainPanel = new AnimalPanel(aPanel);
		
		Container contentPane = getContentPane();
        contentPane.setBackground(Color.WHITE);
		contentPane.setLayout(new BorderLayout());
		contentPane.add(aPanel, BorderLayout.SOUTH);		
		contentPane.add(mainPanel, BorderLayout.CENTER);

		this.pack();
		//displaying the frame
		this.setVisible(true);
		
	}
	
	public static void main(String[] args) {
		new AnimalApp("Fish Tank");
		
	}
}
