import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ControlPanel extends JPanel {
	
	private Container center;
	private JLabel fNum, fdMax, size;
	private JTextField fNumField, sizeField;
	
	private Container top;
	private JButton addFish, b1, b2;
	
	private Container bottom;
	private JLabel statusLabel;
	protected static int foodValue = 6;
	private float sizeValue = 0;
	private float changedValue;
	
	public ControlPanel() {
		setComponentsAttributes();
		
		this.setLayout(new BorderLayout());
		//this.add(statusLabel, BorderLayout.SOUTH);
		this.add(center, BorderLayout.CENTER);
		this.add(bottom, BorderLayout.SOUTH);
		this.add(top, BorderLayout.NORTH);
	}
	
	private void setComponentsAttributes() {
		// top
		fNum = new JLabel("Total Alive Fish: ");
		fdMax = new JLabel("Max Food: ");
		size = new JLabel("Change Size: ");
		
		fNumField = new JTextField(5);
		fNumField.setHorizontalAlignment(SwingConstants.CENTER);
		fNumField.setFocusable(false);
		
		SpinnerModel value = new SpinnerNumberModel(6, 1, 10, 1);
		JSpinner fdMaxField = new JSpinner(value);
		fdMaxField.addChangeListener(new SpinnerListener());
		fdMaxField.setFocusable(false);
		
		sizeField = new JTextField(5);
		sizeField.setHorizontalAlignment(SwingConstants.CENTER);
		sizeField.setFocusable(false);
		b1=new JButton("+");  
	    b1.setBounds(50,200,50,50);  
	    b2=new JButton("-");  
	    b2.setBounds(120,200,50,50);

		center = new Container();
		center.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
		center.add(Box.createHorizontalStrut(2));
		center.add(fNum);
		center.add(fNumField);
		center.add(fdMax);
		center.add(fdMaxField);
		center.add(size);
		center.add(b1);
		center.add(sizeField);
		center.add(b2);
		
		//center
		addFish = new JButton("Add Fish");
		addFish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				AnimalPanel.addFish();		
			}
		});		
		
		b1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==b1) {
					if(sizeValue > 0.00) {
						changedValue = (float) (sizeValue + 0.03);
						AnimalPanel.setSelectedSize(changedValue);
					}
				}
			}
		});
		
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==b2) {
					if(sizeValue > 0.00) {
						changedValue = (float) (sizeValue - 0.03);
						AnimalPanel.setSelectedSize(changedValue);
					}
				}
			}
		});
				
		top = new Container();
		top.setLayout(new FlowLayout(FlowLayout.LEADING));
		top.add(addFish);
		
		// bottom
		statusLabel = new JLabel("Status");
		bottom = new Container();
		bottom.setLayout(new FlowLayout(FlowLayout.LEADING, 12, 5));
		bottom.add(statusLabel);
		bottom.setBackground(Color.DARK_GRAY);
	}
	
	class SpinnerListener implements ChangeListener {
		public void stateChanged(ChangeEvent evt) {
			JSpinner fdMaxField = (JSpinner) evt.getSource();
			foodValue = (int) fdMaxField.getValue();
		}		
	}
	
	public void update(AnimalPanel p) {
		statusLabel.setText(p.getStatus());
		fNumField.setText(String.format("%d", p.countObject(Fish.class)));
		sizeField.setText(String.format("%.2f", selectedSize(p)));
	}
	
	public Float selectedSize(AnimalPanel p) {
		sizeValue = p.getSelectedSize();
		changedValue = sizeValue;
		
		if (sizeValue != changedValue) {
			sizeValue = changedValue;
		}
				
		if(sizeValue > 0.0) {
			return sizeValue;
		}
		return (float) 0.00;
	}	

	public static int getSpinner() {
		return foodValue;
	}

}
