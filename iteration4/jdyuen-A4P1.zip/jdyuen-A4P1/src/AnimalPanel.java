import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.Timer;

public class AnimalPanel extends JPanel implements ActionListener {
	private static ArrayList<SimulationObject> objList;
	private Timer timer;
	private static Dimension panelSize;
	private int maxFood = 6;
	private int maxFish = 5;
	private int maxPred = 2;
	private static int fishCount;
	private static int predCount;
	private static String status = "Status";
	private boolean globalToggle = false;
	private boolean shift, dkey;
	private static ControlPanel cPanel;


	public AnimalPanel(ControlPanel p) {
		super();
		cPanel = p;
		panelSize = new Dimension(1060,600);
		this.setPreferredSize(panelSize);
		this.objList = new ArrayList<>();
		
		for(int i = 0; i < maxFish; i++) {
			objList.add(new Fish(Util.random(50, panelSize.width-50), Util.random(50, panelSize.height-50), Util.random(.1,.15)));		
		}
		
		for(int i = 0; i < maxPred; i++) {
			objList.add(new Predator(Util.random(50, panelSize.width-50), Util.random(50, panelSize.height-50), Util.random(.15,.3)));
		}
		
		for(int i = 0; i < maxFood; i++) {
			objList.add(Util.randomFood(panelSize));
		}

		addMouseListener(new MyMouseAdapter());
		addKeyListener(new MyKeyAdapter());
		setFocusable(true);

		timer = new Timer(33, this);
		timer.start();

	}	
	
	private void drawStatusBar(Graphics2D g) {
		Font font = new Font("Arial", Font.BOLD, 12);
		g.setFont(font);
		FontMetrics metrics = g.getFontMetrics(font);
		
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(0, panelSize.height -metrics.getHeight()*2, panelSize.width, metrics.getHeight()*2);
		
		g.setColor(Color.BLACK);
		g.drawString(status, 24, panelSize.height - (int)(metrics.getHeight()*.75));
	}
	
	private class MyMouseAdapter extends MouseAdapter {
		public void mouseClicked(MouseEvent e){
			for(int i = 0; i < objList.size(); i++) {	
				if (objList.get(i) instanceof Fish && ((Fish) objList.get(i)).checkHit(e)) {
					if ((objList.get(i)).getSelected() == false) {
						(objList.get(i)).setSelected(true);
					}
					else if (( objList.get(i)).getSelected() == true) {
						( objList.get(i)).setSelected(false);
					}
				}
				else if (objList.get(i) instanceof Predator && ((Predator) objList.get(i)).checkHit(e)) {
					if (( objList.get(i)).getSelected() == false) {
						( objList.get(i)).setSelected(true);
					}
					else if (( objList.get(i)).getSelected() == true) {
						( objList.get(i)).setSelected(false);
					}
				}
			}
		}
	}

	private class MyKeyAdapter extends KeyAdapter {
		public void keyPressed(KeyEvent e) {
			if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
				shift = true;
			}
			if (e.getKeyChar() == KeyEvent.VK_D) {
				dkey = true;
			}
			
			if (shift == true && dkey == true) {
				for (SimulationObject obj:objList ) {
					if (globalToggle == false) {
						obj.setToggle(true);
						globalToggle = true;
					}
					else if (globalToggle == true) {
						obj.setToggle(false);
						globalToggle = false;
					}
				}	
			}
		}
		
		public void keyReleased(KeyEvent e) {
			if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
				shift = false;
			}
			if (e.getKeyChar() == KeyEvent.VK_D) {
				dkey = false;
			}
		}
	}


	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		panelSize = getSize();
		setBackground(Color.BLUE);
		Graphics2D g2 = (Graphics2D) g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		//draw objects
		for (SimulationObject obj:objList ) obj.draw(g2);	
		
		cPanel.update(this);

	}	

	@Override
	public void actionPerformed(ActionEvent e) {
		for (int i = 0; i < objList.size(); i++) {
			objList.get(i).update(objList);	
		}

		respawn();
		
		for (SimulationObject obj:objList ) {
			if (globalToggle == false) {
				obj.setToggle(false);
			}
			else if (globalToggle == true) {
				obj.setToggle(true);
			}
		}

		repaint();
		
		maxFood = ControlPanel.getSpinner();
	}
	
	private void respawn() {
		while (countObject(Food.class) < maxFood) objList.add(Util.randomFood(panelSize));
		while (countObject(Fish.class) < maxFish) addFish();
		while (countObject(Predator.class) < maxPred) addPredator();
	}
		
	public int countObject(Class<?> className) {
		return Util.countObject(className, objList);
	}
	
	public static void addPredator() {
		objList.add(Util.randomPredator(panelSize));
		predCount++;
	}
	
	public static void addFish() {
		objList.add(Util.randomFish(panelSize));
		fishCount++;
	}
	
	public static void setStatus(String st) {
		status = st;
	}
	
	public String getStatus() {
		return status;
	}

	public Float getSelectedSize() {
		for(int i = 0; i < objList.size(); i++) {	
			if ((objList.get(i)).getSelected() == true) {
				return objList.get(i).getSize();
			}
		}
		return (float) 0.0;
	}
	
	public static void setSelectedSize(float changedValue) {
		for(int i = 0; i < objList.size(); i++) {	
			if ((objList.get(i)).getSelected() == true) {
				objList.get(i).setSize(changedValue);
			}
		}		
	}	
}
