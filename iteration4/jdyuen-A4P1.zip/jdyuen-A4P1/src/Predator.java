import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Random;

public class Predator extends Animal{
	
	private Color color;
	private Ellipse2D.Double body;
	private Ellipse2D.Double eye;
	private Ellipse2D.Double eye2;
	private Ellipse2D.Double tail2;
	private Arc2D.Double fin11;
	private Arc2D.Double fin22;
	private Arc2D.Double curve;
		
	public Predator(float x, float y, float size) {
		super(x, y, 200, 100, size);
		this.color = Color.GRAY.darker();
	}
	
	@Override
	protected void setShapeAttributes() {
		body = new Ellipse2D.Double(0, -height/2, width*2.5, height*1.5);
		fin11 = new Arc2D.Double(width/4, 150, width, height, 0, 120, Arc2D.PIE);
		fin22 = new Arc2D.Double(width/2 - 10, -220, width, height, 0, -120, Arc2D.PIE);
		eye = new Ellipse2D.Double(width/4, -height/2.9, width/10, width/10); 
		eye2 = new Ellipse2D.Double(width/4, height/1.55, width/10, width/10);
		curve = new Arc2D.Double(width*1.2, 15, width/1.2, height/5, 90,  180, Arc2D.OPEN);

		tail2 = new Ellipse2D.Double(400, -height/2+45, width, height/2);

	}
	
	protected void checkCollision(Dimension panelSize) {
		
		Rectangle2D.Double top = new Rectangle2D.Double(0, -10, panelSize.width, 10);
		Rectangle2D.Double bottom = new Rectangle2D.Double(0, panelSize.height, panelSize.width, 10);
		Rectangle2D.Double left = new Rectangle2D.Double(-10, 0, 10, panelSize.height);
		Rectangle2D.Double right = new Rectangle2D.Double(panelSize.width, 0, 10, panelSize.height);
		
		if (getBoundary().intersects(left) && speed.x < 0) speed.x *= -1;
		if (getBoundary().intersects(right) && speed.x > 0) speed.x *= -1;
		if (getBoundary().intersects(top) && speed.y < 0) speed.y *= -1;
		if (getBoundary().intersects(bottom) && speed.y > 0) speed.y *= -1;
	}
	
	@Override
	protected AffineTransform getAffineTransform() {
		AffineTransform at = new AffineTransform();		
		at.translate(position.x, position.y);
		at.rotate(speed.heading());
		at.scale(-size, -size);
		return at;
	}

	@Override
	protected boolean eatable(SimulationObject food) {
		return (food instanceof Animal && !(food instanceof Predator) && food.getSize() < size);
	}
	
	@Override
	public void draw(Graphics2D g) {
		AffineTransform af = g.getTransform();
		g.translate(position.x, position.y);					
		g.rotate(speed.heading());
		g.scale(-size, -size);

		if (selected == true) {
			drawOutline(g);
		}
		
		g.setStroke(new BasicStroke(1));
		g.setColor(Color.BLACK);
		g.fill(eye);
		g.fill(eye2);
		
		g.setColor(color);
		if (isSick == true) {
			g.setColor(Color.GRAY.brighter());
		}
		g.fill(body);
		
		AffineTransform at = g.getTransform();
		g.rotate(-1.134);
		g.fill(fin11);
		g.setTransform(at);
		
		AffineTransform bt = g.getTransform();
		g.rotate(1.134);
		g.fill(fin22);
		g.setTransform(bt);
		
		g.fill(tail2);
						
		g.setColor(Color.BLACK);
		g.draw(curve);
		
		g.setTransform(af);
		
		g.setColor(Color.BLACK);
		if (toggle == true) {
			drawInfo(g);
		}
		
		if (selected == true) {
			drawInfo(g);
		}
		
		g.setStroke(new BasicStroke(1));
		
//		g.setColor(Color.red);
//		g.draw(getBoundary().getBounds2D());		
	}
	
	protected void drawOutline(Graphics2D g) {
		g.setColor(Color.RED);
		g.setStroke(new BasicStroke(50));
		g.draw(body);		
		AffineTransform at = g.getTransform();
		g.rotate(-1.134);
		g.draw(fin11);
		g.setTransform(at);
		AffineTransform bt = g.getTransform();
		g.rotate(1.134);
		g.draw(fin22);
		g.setTransform(bt);
		g.draw(tail2);
	}

	@Override
	protected void setBoundingBox() {
		boundingBox = new Area(body);
		boundingBox.add(new Area(tail2));
		boundingBox.add(new Area(fin11));
	}
}
