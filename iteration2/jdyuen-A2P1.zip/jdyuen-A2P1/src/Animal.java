import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.util.Random;
import processing.core.PVector;

public class Animal {
    private static PVector pos;
	private PVector speed, path, vel, smallest;
	private Color animalColor;
	private static int size;
	private double scale;
	private float angle, rotation = 0;
	private boolean edge = false;

	Random num = new Random();
	private int stripe = num.nextInt(2);
	private int tailSize = num.nextInt(2);

	public Animal(int x, int y, int size, int speedx, int speedy, Color c, double s1) {
		this.size = size;
		this.pos = new PVector(x, y);
	    this.speed = new PVector(speedx, speedy);
	    this.scale = s1;
		animalColor = c;
	}
	
	public void movement() {
		if (AnimalPanel.foodOut() == true) {
			float d, e = 10000;
			for (int i = 0; i < AnimalPanel.getFoodList().size(); i++) {
				PVector food = AnimalPanel.getFoodList().get(i).foodPos;
				PVector animal = Animal.pos;
				d = food.dist(animal);
				if (e > d) {
					e = d;
					smallest = AnimalPanel.getFoodList().get(i).foodPos;
				}	
			}			
			PVector path = PVector.sub(smallest, Animal.pos);
			angle = path.heading();
			vel = PVector.fromAngle(angle);
			vel.mult(5);
			Animal.pos.add(vel);
		}
		
		else {	
			angle = speed.heading();
			Animal.pos.add(speed);
		}
	}
	
	public void checkCollision(Dimension panelSize) {

		if ((pos.x < size * scale*1.5) ||  ((pos.x > panelSize.width - size * scale*1.5))) {
			edge = true;
			speed.x *= -1;
		}

		if ((pos.y < size * scale*1.5) || ((pos.y > panelSize.height - size*2 * scale))) {
			edge = true;
			speed.y *= -1;
		}
	}

	public static Rectangle bounds() {
		return (new Rectangle((int) pos.x-10, (int) pos.y-15, size/2,size/2));
	}
	
	public void drawAnimal(Graphics2D g) {
		AffineTransform af = g.getTransform();
		g.translate((int)pos.x, (int)pos.y);			
		if (AnimalPanel.foodOut() == true) { 
			g.rotate(angle);	
			edge = false;
		}
		
		if (edge == true) {
			g.rotate(angle);
		}
		
		
		g.scale(-scale/2, -scale/2);
		
		g.setColor(animalColor);
						
		g.fillOval(-size/2, -size/2, size*3, size); 	// draw body
		
		g.fillOval(size/3, size/2 - size/2, size/2, size); // draw fins
		g.fillOval(size/3, -size - size/20, size/2, size); 
		
		g.setColor(Color.BLACK);
		g.fillOval(-size/6, -size/3, size/5, size/5); 	// draw eyes
		g.fillOval(-size/6, size/7, size/5, size/5);

		
		if (stripe == 0) {
			g.drawLine(size/2, -size/4, size + size/2, -size/4);
			g.drawLine(size/2, size/4, size + size/2, size/4);
			g.drawLine(size/2, size/4 - size/4, size + size/2, size/4 - size/4);
		}

		else {
			g.drawLine(size/2, -size/5, size + size/2, -size/5);
			g.drawLine(size/2, size/5, size + size/2, size/5);
		}
		
		g.setColor(animalColor);
		if (tailSize == 0) {		// draw tail
			g.fillOval(size + size, -size/5, size, size/3);
			g.fillOval(size + size, -size/3 - size/10, size, size/3);
			g.fillOval(size + size, size/20, size, size/3);
		}
		else {		
			g.fillOval(size + size, -size/5, size, size/3);
		}
		g.setTransform(af);

	}
}