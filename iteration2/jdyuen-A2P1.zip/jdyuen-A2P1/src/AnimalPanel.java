import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.Timer;

public class AnimalPanel extends JPanel implements ActionListener {
	private Animal animal;
	private static ArrayList<Food> foodList;
	private Timer timer;
	private int foodX, foodY;
	private boolean remove;
	private static boolean isfood = false;
	private boolean grow = false;
	private Dimension panelSize;

	public AnimalPanel(Dimension initialSize) {
		super();
		this.panelSize = initialSize;
		animal = new Animal(initialSize.width/3, initialSize.height/2, Math.min(initialSize.width,initialSize.height)/10, 
				5, 5, Color.orange, 1);

		
		this.foodList = new ArrayList<Food>();

		addMouseListener(new MyMouseAdapter());

		timer = new Timer(33, this);
		timer.start();

	}	

	private class MyMouseAdapter extends MouseAdapter {
		public void mouseClicked(MouseEvent e){
			for(int i = 0; i < getFoodList().size(); ++i) {		
				if( getFoodList().get(i).checkFoodHit(e) && (e.getModifiersEx() & InputEvent.CTRL_DOWN_MASK) >0) {
					getFoodList().remove(i);
					remove = true;
					if (getFoodList().isEmpty()) {
						isfood = false;
					}
					break;
				}				
				if (getFoodList().get(i).checkFoodHit(e)) { 
					getFoodList().get(i).enlarge(); 
					grow = true;
					break;	
				}
			}
			if (grow == false && remove == false) {
				foodX = e.getX();
				foodY = e.getY();
				getFoodList().add(new Food(foodX, foodY, Color.GREEN, Math.min(panelSize.width, panelSize.height)/10));
				isfood = true;
			}
			grow = false;
			remove = false;
		}
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		setBackground(Color.GRAY);
		Graphics2D g2 = (Graphics2D) g;
		if (isfood == true) {
			for (Food f : getFoodList()) f.drawFood(g2);			
		}
		animal.drawAnimal(g2);
	}	

	@Override
	public void actionPerformed(ActionEvent e) {
		animal.movement();	
		collision();
		animal.checkCollision(panelSize);
		repaint();	
		
	}
	
	public void collision() {
		for(int i = 0; i < getFoodList().size(); ++i) {
			Rectangle rectangleFish = Animal.bounds();
			Rectangle rectangle1 = getFoodList().get(i).bounds();
			
			if (rectangleFish.intersects(rectangle1)){
				getFoodList().remove(i);
				if (getFoodList().isEmpty()) {
					isfood = false;
				}
			}
		}
	}
	
	public static boolean foodOut() {
		return isfood;
	}

	public static ArrayList<Food> getFoodList() {
		return foodList;
	}

	public static void setFoodList(ArrayList<Food> foodList) {
		AnimalPanel.foodList = foodList;
	}
	
}
