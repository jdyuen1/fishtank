import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.util.Random;
import processing.core.PVector;
import java.awt.event.MouseEvent;


public class Food {

	private int size;
	PVector foodPos;
	private Color foodColor;
	private double scale;
		
	public Food(int x, int y, Color c, int size) {
	    foodPos = new PVector(x, y);
	    foodColor = c;
	    this.size = size;
	    this.scale = 1;
	}
	
	public void drawFood(Graphics2D g) { 
		AffineTransform af = g.getTransform();
		g.translate((int)foodPos.x, (int)foodPos.y);
		g.scale(scale, scale);
		g.setColor(foodColor);
		g.fillArc(-10, -20, 30, 30, 90, 180);
		g.fillArc(-20, 5, 30, 30, -90, 180);
		g.setColor(Color.blue);
		g.setTransform(af);

	}
	
	public void enlarge() {
		this.scale *= 1.1;
	}
	
	public boolean checkFoodHit(MouseEvent e) {
		return (Math.abs(e.getX()-foodPos.x) < (size/ 2)*scale && 
				Math.abs(e.getY()-foodPos.y) < (size/ 2)*scale);
	}
	
	public Rectangle bounds() {
		return (new Rectangle((int)(foodPos.x-size*scale/4), (int)(foodPos.y-size*scale/3), (int)(size*scale/2), (int)(size*scale)));
	}

	public PVector getFoodPos() {
		return foodPos;
	}
	
}
