import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import processing.core.PVector;
import java.awt.Dimension;



public class Food {

	private PVector foodPos;
	private Color foodColor;
	private float scale;
	private Arc2D.Double foodShape1;
	private Arc2D.Double foodShape2;
	private Rectangle2D bBox;
	private Area outline;

		
	public Food(float x, float y, float size) {
	    foodPos = new PVector(x, y);
	    foodColor = Color.GREEN;
	    this.scale = size;
	    setShapeAttributes();
	    setOutline();
	    getBoundingBox();
	}
	
	private void setOutline() {
		outline = new Area();
		outline.add(new Area(foodShape1));
		outline.add(new Area(foodShape2));
	}

	private Rectangle2D getBoundingBox() {
		bBox = outline.getBounds2D();
		return bBox;
	}

	private void setShapeAttributes() {
		this.foodShape1 = new Arc2D.Double(-10, -20, 30, 30, 90, 180, Arc2D.PIE);
		this.foodShape2 = new Arc2D.Double(-20, 5, 30, 30, -90, 180, Arc2D.PIE);
	}

	public Shape getBoundary() {
		AffineTransform at = new AffineTransform();		
		at.translate(foodPos.x, foodPos.y);
		at.scale(scale, scale);
		return at.createTransformedShape(bBox);
	}
	
	public void drawFood(Graphics2D g) { 
		AffineTransform af = g.getTransform();
		g.translate(foodPos.x, foodPos.y);
		g.scale(scale, scale);
		g.setColor(foodColor);
		g.fill(foodShape1);
		g.fill(foodShape2);
		g.setTransform(af);

	}
	
	public boolean checkFoodHit(MouseEvent e) {
		return getBoundary().contains(e.getX(), e.getY());
	}
	
	public PVector getFoodPos() {
		return foodPos;
	}
	
	public float getSize() {
		return scale;
	}
}
