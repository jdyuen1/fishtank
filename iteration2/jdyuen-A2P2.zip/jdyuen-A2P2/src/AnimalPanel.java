import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.ListIterator;

import javax.swing.JPanel;
import javax.swing.Timer;
import processing.core.PVector;


public class AnimalPanel extends JPanel implements ActionListener {
	private ArrayList<Animal> animalList;
	private ArrayList<Food> foodList;
	private Timer timer;
	private Dimension panelSize;

	public AnimalPanel(Dimension initialSize) {
		super();
		this.panelSize = initialSize;
		
		this.animalList = new ArrayList<>();
		for(int i = 0; i < 2; i++) {
			animalList.add(new Animal(Util.random(50, panelSize.width-50), Util.random(50, panelSize.height-50), Util.random(.1,.3), 400));
		}

		
		this.foodList = new ArrayList<Food>();
		for(int i = 0; i < 4; i++) {
			foodList.add(new Food(Util.random(100, panelSize.width-100), Util.random(100, panelSize.height-100), Util.random(.5, 1.5)));
		}

//		addMouseListener(new MyMouseAdapter());

		timer = new Timer(33, this);
		timer.start();

	}	

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		setBackground(Color.WHITE);
		Graphics2D g2 = (Graphics2D) g;
		for (Food f : foodList) f.drawFood(g2);			
		for (Animal a : animalList) a.drawAnimal(g2);
	}	

	@Override
	public void actionPerformed(ActionEvent e) {
		for (ListIterator<Animal> it = animalList.listIterator(); it.hasNext(); ) {
			Animal a = it.next();
			hunger(a);
			System.out.println(a.getEnergy());
			if(a.getEnergy() < 150) {
				a.setSick();
			}
			if (a.getEnergy() <= 0) {
				it.remove();
				it.add(new Animal(Util.random(50, panelSize.width-50), Util.random(50, panelSize.height-50), Util.random(.1,.3), 400));
			}
			Food target = closestFood(a);
			if (target != null) {
				a.attractedBy(target);
			}
			a.movement();
			
			for (int i = 0; i < foodList.size(); i++) {
				if (a.collides(foodList.get(i))) {
					a.setEnergy(foodList.get(i).getSize());
					foodList.remove(i);
					foodList.add(new Food (Util.random(100, panelSize.width-100), Util.random(100, panelSize.height-100), Util.random(.5, 1.5)));
				}
			}
			
			for (int i = 0; i < animalList.size(); i++)
				if (a != animalList.get(i) && a.collides(animalList.get(i))) {
					if (a.getSize() < animalList.get(i).getSize()) {
						a.distractedBy(animalList.get(i));
					}
					else {
						animalList.get(i).distractedBy(a);
					}
				}
			a.checkCollision(getSize());	
		}	
		repaint();	
	}
	
	private void hunger(Animal a) {
		a.starve();
	}
	
	private Food closestFood(Animal a) {
		Food closestFood = null;
		if (foodList.size() > 0) {
			closestFood = foodList.get(0);
			float closestDistance = PVector.dist(a.getPos(), closestFood.getFoodPos());
			for (Food f : foodList) {
				float force = (f.getSize() / PVector.dist(a.getPos(), f.getFoodPos())) * 50000;
				if (PVector.dist(a.getPos(), f.getFoodPos()) < force) {
					closestFood = f;
					closestDistance = PVector.dist(a.getPos(), closestFood.getFoodPos());
					force = (closestFood.getSize() / closestDistance) * 50000;
				}
			}
		}
		return closestFood;
	}
	
	
}
