import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.util.Random;
import processing.core.PVector;
import java.awt.Panel;
import java.awt.geom.*;


public class Animal {
	private PVector speed, pos;
	private Color animalColor;
	private float scale;
	private float maxSpeed;	
	private Dimension dimension;
	private float energy;
	private boolean sick = false;
	
	private Ellipse2D.Double body;
	private Ellipse2D.Double eye;
	private Ellipse2D.Double eye2;
	private Ellipse2D.Double tail;
	private Ellipse2D.Double tail2;
	private Ellipse2D.Double tail3;
	private Ellipse2D.Double fin;
	private Ellipse2D.Double fin2;	
	private Arc2D.Double curve;
	private Arc2D.Double curve2;
	private Arc2D.Double curve3;

	private Area bBox;

	Random num = new Random();
	private int stripe = num.nextInt(2);
	private int tailSize = num.nextInt(2);

	public Animal(float x, float y, float size, float energy) {
		this.scale = size;
		this.energy = energy;
		this.pos = new PVector(x, y);
	    while (maxSpeed == 0) {
	    	this.maxSpeed = 9 - (size * 10);
	    }
		this.speed = Util.randomPVector(maxSpeed);
		animalColor = Color.ORANGE;
		this.dimension = new Dimension(200,100);
		setShapeAttributes();
	}
	
	private void setShapeAttributes() {
		body = new Ellipse2D.Double(0, -dimension.height/2, dimension.width*2.25, dimension.height*1.5);
		fin = new Ellipse2D.Double(100, 0, dimension.width/3, dimension.height*2);
		fin2 = new Ellipse2D.Double(100, -150, dimension.width/3, dimension.height*2);
		eye = new Ellipse2D.Double(dimension.width/4, -dimension.height/10, dimension.width/10, dimension.width/10); 
		eye2 = new Ellipse2D.Double(dimension.width/4, dimension.height/3, dimension.width/10, dimension.width/10);
		curve = new Arc2D.Double(dimension.width/2 + 30, 25, dimension.width, dimension.width/10 - 20, 0, 180, Arc2D.OPEN);
		curve2 = new Arc2D.Double(dimension.width/2 + 30, 10, dimension.width, dimension.width/10 - 20, 0, 180, Arc2D.OPEN);
		curve3 = new Arc2D.Double(dimension.width/2 + 30, 40, dimension.width, dimension.width/10 - 20, 0, 180, Arc2D.OPEN);

		tail = new Ellipse2D.Double(300, -dimension.height/2+25, dimension.width, dimension.height/2);
		tail2 = new Ellipse2D.Double(300, -dimension.height/2+45, dimension.width, dimension.height/2);
		tail3 = new Ellipse2D.Double(300, -dimension.height/2+65, dimension.width, dimension.height/2);
		
		bBox = new Area(body);
		bBox.add(new Area(tail));
		bBox.add(new Area(tail2));
		bBox.add(new Area(tail3));
		bBox.add(new Area(fin));
		bBox.add(new Area(fin2));
		
	}

	public void movement() {
		pos.add(speed);
	}

	public PVector getPos() {
		return pos;
	}
	
	public void checkCollision(Dimension panelSize) {
	
		Rectangle2D.Double top = new Rectangle2D.Double(0, -10, panelSize.width, 10);
		Rectangle2D.Double bottom = new Rectangle2D.Double(0, panelSize.height, panelSize.width, 10);
		Rectangle2D.Double left = new Rectangle2D.Double(-10, 0, 10, panelSize.height);
		Rectangle2D.Double right = new Rectangle2D.Double(panelSize.width, 0, 10, panelSize.height);
		
		if (getBoundary().intersects(left) && speed.x < 0) speed.x *= -1;
		if (getBoundary().intersects(right) && speed.x > 0) speed.x *= -1;
		if (getBoundary().intersects(top) && speed.y < 0) speed.y *= -1;
		if (getBoundary().intersects(bottom) && speed.y > 0) speed.y *= -1;
	}
	
	private Shape getBoundary() {
		AffineTransform at = new AffineTransform();		
		at.translate(pos.x, pos.y);
		at.rotate(speed.heading());
		at.scale(-scale, -scale);
		return at.createTransformedShape(bBox);
	}
	
	public boolean checkMouseHit(MouseEvent e) {
		return getBoundary().contains(e.getX(), e.getY());
	}
	
	public void attractedBy(Food target) {
		PVector path = PVector.sub(target.getFoodPos(), pos);
		speed.add(path.normalize().mult(maxSpeed*.2f)).limit(maxSpeed);
	}

	public boolean collides(Food food) {
		return (getBoundary().intersects(food.getBoundary().getBounds2D()) &&
				food.getBoundary().intersects(getBoundary().getBounds2D()) );
	}

	public boolean collides(Animal a) {
		return (getBoundary().intersects(a.getBoundary().getBounds2D()) &&
				a.getBoundary().intersects(getBoundary().getBounds2D()) );
	}

	public void distractedBy(Animal a) {
		PVector path = PVector.sub(pos, a.pos);
		speed.add(path.normalize().mult(maxSpeed*5f)).limit(maxSpeed);
	}
	
	public float getSize() {
		return scale;
	}
	
	public float starve() {
		return energy = energy - (scale * 5);
	}
	
	public float getEnergy() {
		return energy;
	}
	
	public float setEnergy(float size) {
		return energy = energy + (size * 10);
	}
	
	public boolean setSick() {
		sick = true;
		return sick;
	}
	
	public PVector getSpeed() {
		return speed;
	}
	
	public void drawAnimal(Graphics2D g) {
		AffineTransform af = g.getTransform();
		g.translate(pos.x, pos.y);					
		g.rotate(speed.heading());
		g.scale(-scale, -scale);

		g.setColor(animalColor);
		if (sick == true) {
			g.setColor(Color.GREEN.darker());
			speed.mult(.5f).limit(maxSpeed);
		}
		
		g.fill(body);
		
		g.fill(fin);
		g.fill(fin2);
		
		if (tailSize == 0) {		
			g.fill(tail);
			g.fill(tail2);
			g.fill(tail3);
		}
		else {		
			g.fill(tail2);
		}
						
		g.setColor(Color.BLACK);
		g.fill(eye);
		g.fill(eye2);

		if (stripe == 0) {
			g.draw(curve);
		}
		else {
			g.draw(curve2);
			g.draw(curve3);
		}
		g.setTransform(af);
		
//		g.setColor(Color.red);
//		g.draw(getBoundary().getBounds2D());
	}
}